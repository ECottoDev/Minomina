import { addClasses, addEvent, appendChildren, createButton, createElementContainer, createHeadingText, createPillBox, createSVG, delayedListener } from "../../../../helpers/basicElements.js";
import { rebootInstances } from "../../../databaseCallers/awsDataCalls.js";

export class InstanceTiles {
    constructor(parentProps, instance, refresh = () => { }) {
        this.refresh = refresh;
        this.parentProps = parentProps;
        this.instance = instance;
        this.view = addClasses(createPillBox(true), 'instanceTiles_view')
        this.setView()
    }
    async setView() {
        appendChildren(this.view, [
            appendChildren(addClasses(createElementContainer(), 'instanceTiles_leftContainer'), [
                createHeadingText(this.instance.InstanceName),
            ]),
            appendChildren(addClasses(createElementContainer(), 'instanceTiles_middleContainer'), [
                this.instance.State == 'running' ? addClasses(createSVG('frontend/assets/icons/greenCheckmark.svg'), 'instanceTiles_checkmark') : addClasses(createSVG('frontend/assets/icons/errorCircle2.svg'), 'instanceTiles_errorMark'),
            ]),
            appendChildren(addClasses(createElementContainer(), 'instanceTiles_rightContainer'), [
                this.instance.ServiceReachable ? addClasses(createSVG('frontend/assets/icons/greenCheckmark.svg'), 'instanceTiles_checkmark') : addClasses(createSVG('frontend/assets/icons/errorCircle2.svg'), 'instanceTiles_errorMark'),
            ]),
            appendChildren(addClasses(createElementContainer(), 'instanceTiles_buttons'), [
                this.instance.State == 'running' ? addEvent(addClasses(createButton('Start'), 'instanceTiles_rebootButton-disabled'), async () => { }) : addEvent(addClasses(createButton('Start'), 'instanceTiles_rebootButton'), async () => { }),
                this.instance.State == 'running' ? addEvent(addClasses(createButton('Stop'), 'instanceTiles_rebootButton'), async () => { }) : addEvent(addClasses(createButton('Stop'), 'instanceTiles_rebootButton-disabled'), async () => { }),
                this.instance.State == 'running' ? addEvent(addClasses(createButton('Reboot'), 'instanceTiles_rebootButton'), async () => { this.handleReboot() }) : addEvent(addClasses(createButton('Reboot'), 'instanceTiles_rebootButton-disabled'), async () => { this.handleReboot() })

            ])
        ])
    }
    async handleReboot() {
        await rebootInstances(this.instance.InstanceId);
        this.refresh();
    }
}