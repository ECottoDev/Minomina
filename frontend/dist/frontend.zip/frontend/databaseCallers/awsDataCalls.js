// const link = 'https://odmx2bmcuubrl3zbghvtfdvwie0hnpbh.lambda-url.us-east-1.on.aws';
const link = 'https://8x4y7u6c7h.execute-api.us-east-1.amazonaws.com/dev';

export async function getInstances2() {
    try {
        const response = await fetch(`https://il73qtmn76ut2yd2pxldygecje0ecyfa.lambda-url.us-east-2.on.aws/`, {

        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        console.log(data);
        return data; // Assuming data is already structured correctly by Lambda
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

export async function rebootInstances(instance) {
    try {
        const response = await fetch(`https://rdlkh83jzi.execute-api.us-east-1.amazonaws.com/Prod/instances/${instance}`, {
            method: 'PUT', // Change to POST method
            //body: JSON.stringify({ InstanceIds: instance }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        return data; // Assuming data is already structured correctly by Lambda
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

export async function getInstances() {
    try {
        const response = await fetch('https://rdlkh83jzi.execute-api.us-east-1.amazonaws.com/Prod/instances', {
            //headers: { 'Access-Control-Allow-Origin': '*' }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        return JSON.parse(data.body)
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

export async function logIn(username, password) {
    try {
        const response = await fetch('https://nzqrjftbeicexe2alddiykhkna0phjvk.lambda-url.us-east-1.on.aws/', {
            method: 'POST', // Change to POST method
            body: JSON.stringify({ user: username, pass: password }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        console.log(data)
        // return data; // Assuming data is already structured correctly by Lambda
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

export async function getWorld() {
    try {
        const response = await fetch('https://rdlkh83jzi.execute-api.us-east-1.amazonaws.com/Prod/instances', {
            method: "GET"
            //headers: { 'Access-Control-Allow-Origin': '*' }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        return data; // Assuming data is already structured correctly by Lambda
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}