import { addClasses, addEvent, appendChildren, createButton, createElementContainer, createInputBar } from "../../../helpers/basicElements.js";
import { getWorld, logIn } from "../../databaseCallers/awsDataCalls.js";

export class LogIn {
    constructor(parentProps) {
        this.parentProps = parentProps;

        this.view = addClasses(createElementContainer(), 'logIn_view');
        //this.setView();
        this.helloworld()
    }
    async helloworld() {
        const data = await getWorld()

        console.log(data.body)

    }
    // setView() {
    //     appendChildren(this.view, [
    //         this.user = createInputBar({ placeHolder: 'Username', id: 'user' }),
    //         this.pass = createInputBar({ placeHolder: 'Password', id: 'pass' }),
    //         addEvent(createButton('Log in'), () => { logIn(this.user.value, this.pass.value) })
    //     ])
    // }

}