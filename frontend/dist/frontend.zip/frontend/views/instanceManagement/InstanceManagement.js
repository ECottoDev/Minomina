import { addClasses, addEvent, appendChildren, createButton, createElementContainer, createHeadingText, createImg, createTextArea, delayedExecution, delayedListener, detachChildren, sortArrayOfObj } from "../../../helpers/basicElements.js";
import { InstanceTiles } from "../../components/tiles/instanceTiles/InstanceTiles.js";
import { getInstances, getInstances2, rebootInstances } from "../../databaseCallers/awsDataCalls.js";

export class InstanceManagement {
    constructor(parentProps) {
        this.parentProps = parentProps;
        this.view = addClasses(createElementContainer(), 'instanceManagement_view');
        this.handleRefresh = delayedExecution(this.handleRefresh.bind(this), 10000);
        this.setView();
    }
    async setView() {
        appendChildren(this.view, [
            appendChildren(addClasses(createElementContainer(), 'instanceManagement_columnTitles'), [
                addClasses(createHeadingText(`Instance Name: `), 'instanceManagement_instanceNameText'),
                addClasses(createHeadingText(`State: `), 'instanceManagement_stateText'),
                addClasses(createHeadingText(`Reachablitity: `), 'instanceManagement_reachableText'),

            ]),
            this.loading = createImg('frontend/assets/icons/loading.svg'),
            addClasses(this.loading, 'instanceManagement_loading'),
        ]);
        await this.fetch()
        //this.handleRefresh();
    }
    async fetch() {
        this.instances = await getInstances();
        this.instances.sort(sortArrayOfObj('InstanceName'));

        try {
            this.promises = await this.instances.map(entry =>
                new InstanceTiles(this.parentProps, entry, delayedListener(() => { detachChildren(this.view); this.setView(); }, 1000)).view
            );
            this.loading.remove();
        } finally {
            appendChildren(this.view, this.promises);
        }
    }
    async handleRefresh() {
        detachChildren(this.view);
        await this.setView();
        delayedExecution(async () => { await this.handleRefresh(); }, 10000)();
    }
}
